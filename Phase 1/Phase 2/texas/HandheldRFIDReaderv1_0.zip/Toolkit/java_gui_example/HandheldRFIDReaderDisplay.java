/* $Header: /home/cvs/handheldreader/java_gui_example/HandheldRFIDReaderDisplay.java,v 1.1 2003/12/01 19:00:00 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class HandheldRFIDReaderDisplay extends JFrame implements ActionListener {

	HandheldRFIDReader reader;
	String device;
	JButton connectButton;
	JButton startProcessingIncomingButton;
	JButton stopProcessingIncomingButton;
	JButton disconnectButton;
	JTextArea textArea;

	public HandheldRFIDReaderDisplay(String device) {
		reader = new HandheldRFIDReader(this);
		this.device = device;
		setTitle("HandheldRFIDReader demo program");
		setSize(600,400);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		getContentPane().setLayout(new BorderLayout());
		JPanel mainPanel = new JPanel();
		getContentPane().add(new JLabel("Tags seen:",JLabel.CENTER),BorderLayout.NORTH);
		textArea = new JTextArea(20,25);
		JScrollPane scrollpane = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		textArea.setEditable(false);
		mainPanel.add(scrollpane);
		getContentPane().add(mainPanel,BorderLayout.CENTER);
		JPanel buttonPanel = new JPanel();
		connectButton = new JButton("Connect");
		connectButton.addActionListener(this);
		connectButton.setEnabled(true);
		buttonPanel.add(connectButton);
		startProcessingIncomingButton = new JButton("Process Incoming");
		startProcessingIncomingButton.addActionListener(this);
		startProcessingIncomingButton.setEnabled(false);
		buttonPanel.add(startProcessingIncomingButton);
		stopProcessingIncomingButton = new JButton("Stop Incoming");
		stopProcessingIncomingButton.addActionListener(this);
		stopProcessingIncomingButton.setEnabled(false);
		buttonPanel.add(stopProcessingIncomingButton);
		disconnectButton = new JButton("Disconnect");
		disconnectButton.addActionListener(this);
		disconnectButton.setEnabled(false);
		buttonPanel.add(disconnectButton);
		getContentPane().add(buttonPanel,BorderLayout.SOUTH);
		show();
	}
	public void actionPerformed(ActionEvent e) {
		if ( e.getSource() == connectButton ) {
			int ret = reader.connect(device);
			if ( ret != 0 ) {
				System.err.println("connection failed!");
				return;
			}
			connectButton.setEnabled(false);
			startProcessingIncomingButton.setEnabled(true);
			stopProcessingIncomingButton.setEnabled(false);
			disconnectButton.setEnabled(true);
		}
		if ( e.getSource() == startProcessingIncomingButton ) {
			int ret = reader.startProcessingIncomingMessages();
			if ( ret != 0 ) {
				System.err.println("start incoming failed!");
				return;
			}
			connectButton.setEnabled(false);
			startProcessingIncomingButton.setEnabled(false);
			stopProcessingIncomingButton.setEnabled(true);
			disconnectButton.setEnabled(false);
		}
		if ( e.getSource() == stopProcessingIncomingButton ) {
			int ret = reader.stopProcessingIncomingMessages();
			if ( ret != 0 ) {
				System.err.println("stop incoming failed!");
				return;
			}
			connectButton.setEnabled(false);
			startProcessingIncomingButton.setEnabled(true);
			stopProcessingIncomingButton.setEnabled(false);
			disconnectButton.setEnabled(true);
		}
		if ( e.getSource() == disconnectButton ) {
			int ret = reader.disconnect();
			if ( ret != 0 ) {
				System.err.println("disconnect failed!");
				return;
			}
			connectButton.setEnabled(true);
			startProcessingIncomingButton.setEnabled(false);
			stopProcessingIncomingButton.setEnabled(false);
			disconnectButton.setEnabled(false);
		}
	}
	public void updateStatus(String status) {
		textArea.insert(status+ "\n",0);
	}
	public static void main(String[] args) {
		if (args.length == 0 ) {
			System.out.println("usage: HandheldRFIDReaderDisplay portname e.g. \"COM3\" or \"/dev/ttyUSB0\"");
			System.exit(0);
		}
		HandheldRFIDReaderDisplay display = new HandheldRFIDReaderDisplay(args[0]);
		// ? show
	}
}
	
