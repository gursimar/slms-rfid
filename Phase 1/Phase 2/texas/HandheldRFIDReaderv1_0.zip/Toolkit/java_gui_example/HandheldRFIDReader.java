/* $Header: /home/cvs/handheldreader/java_gui_example/HandheldRFIDReader.java,v 1.2 2003/12/01 19:13:13 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/

import java.util.*;

/**
 * This is a simple Java class that demonstrates how to use the HandheldRFIDReader's
 * JNI library to register for tag seen notifications. 
 ***/

class HandheldRFIDReader {
	public long cplusplus_peer;
	protected HandheldRFIDReaderDisplay gui;
	public native long HandheldRFIDReader_init();
	public native int HandheldRFIDReader_cleanup(long cplusplus_peer);
	public native int HandheldRFIDReader_connect(String device, long cplusplus_peer);
	public native int HandheldRFIDReader_startProcessingIncomingMessages(long cplusplus_peer);
	public native int HandheldRFIDReader_stopProcessingIncomingMessages(long cplusplus_peer);
	public native int HandheldRFIDReader_disconnect(long cplusplus_peer);

	public HandheldRFIDReader() {
		this.gui = null;
		cplusplus_peer = HandheldRFIDReader_init();
	}
	public HandheldRFIDReader(HandheldRFIDReaderDisplay gui) {
		this.gui = gui;
		cplusplus_peer = HandheldRFIDReader_init();
	}
	public int destroy() {
		int ret = HandheldRFIDReader_cleanup(cplusplus_peer);
		cplusplus_peer = 0;
		return ret;
	}
	public int connect(String device) {
		return HandheldRFIDReader_connect(device,cplusplus_peer);
	}
	public int startProcessingIncomingMessages() {
		return HandheldRFIDReader_startProcessingIncomingMessages(cplusplus_peer);
	}
	public int stopProcessingIncomingMessages() {
		return HandheldRFIDReader_stopProcessingIncomingMessages(cplusplus_peer);
	}
	public int disconnect() {
		return HandheldRFIDReader_disconnect(cplusplus_peer);
	}
	/***
	 * The JNI library will callback this method whenever it sees a tag
	 * @param a seen tag
	 * @returns 0
	 ***/
	public int processReadTagHeaderReplyMessage(String tag) {
		if ( gui != null ) gui.updateStatus(tag);
		System.out.println("in java tag header: " + tag);
		return 0;
	}
	public static void main(String[] args) {
		if ( args.length != 1 ) {
			System.err.println("need a com port or /dev/ttyUSB");
			System.exit(1);
		}
		HandheldRFIDReader reader = new HandheldRFIDReader();
		reader.connect(args[0]);
		reader.startProcessingIncomingMessages();
		try {
			Thread.sleep(600*1000);
		} catch (InterruptedException e) { ; }
		reader.stopProcessingIncomingMessages();
		reader.disconnect();
	}
	static {
		System.loadLibrary("HandheldRFIDReader");
	}
}

