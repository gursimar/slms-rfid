/* $Header: /home/cvs/handheldreader/src/HandheldRFIDReader.cpp,v 1.3 2003/12/02 20:21:21 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/

#if defined(_MSC_VER)
#include <windows.h>
#else
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <pthread.h>
#include <poll.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>
extern int errno;
#endif
#include <stdio.h>
#include "HandheldRFIDReader.hpp"
#include "MoteMsg.hpp"
#include "chars.h"

/***
 * Constructor.
 ***/
HandheldRFIDReader::HandheldRFIDReader() { 
	BaudRate = BAUDRATE;
	_ctor();
}
/***
 * Constructor.
 ***/
HandheldRFIDReader::HandheldRFIDReader(int baudrate) { 
	BaudRate = baudrate;
	_ctor();
}
/***
 * Destructor
 ***/
HandheldRFIDReader::~HandheldRFIDReader() { ; }
/***
 * connect to the adapter.
 * returns 0 if OK, -1 if not
 ***/
int HandheldRFIDReader::connect(char *device) {
	return _connect(device);
}
/***
 * disconnect from adapter
 * returns 0 if OK, -1 if not
 ***/
int HandheldRFIDReader::disconnect() {
	return _disconnect();
}
/***
 * start listening for incoming messages on a separate thread
 * returns 0 if OK, -1 if not
 ***/
int HandheldRFIDReader::startProcessingIncomingMessages() {
	return _startProcessingIncomingMessages();
}
/***
 * stop listening for incoming messages
 * returns 0 if OK -1 if not
 ***/
int HandheldRFIDReader::stopProcessingIncomingMessages() {
	return _stopProcessingIncomingMessages();
}
/***
 * got an incoming shallow read message. Override this to do what you want.
 * default behavior is to just print it out
 **/
#ifndef JNI_WRAPPER
int HandheldRFIDReader::processReadTagHeaderReplyMessage(int length, CHAR *payload) {
	printf("processReadTagHeaderReplyMessage: received a tag id:");
	for ( int i = 0 ; i < length ; i++ ) printf("%c",payload[i]);
	printf("\n");
	return 0;
}
#else
#if defined(_MSC_VER)
#pragma message("using JNI_wrapper for processReadTagHeaderRelyMessage definition")
#else
#warning "using JNI_wrapper for processReadTagHeaderRelyMessage definition"
#endif
#endif

/***
 * Incoming data has been read. Try to parse it.
 * length is the length of the new data
 * tmpbuf is the buffer
 ***/
void HandheldRFIDReader::processIncomingData(int length, CHAR *tmpbuf) {

	static MoteMsg *motemsg = NULL;
	if ( motemsg == (MoteMsg *)NULL ) {
		motemsg = new MoteMsg();
	}

	bool beenThroughLoop = false;

	while ( true ) {

		if ( motemsg->isBadMessage() == true ) {
			fprintf(stderr,"bad message; giving up\n");
			delete motemsg;
			motemsg = NULL;
			return;	
		}

		if ( motemsg->isCompleteMessage() == true ) {
			// got a complete message - now dispatch it
			if ( motemsg->getMessageType() == ID_MESSAGE_TYPE ) {
				processReadTagHeaderReplyMessage(motemsg->getRFIDReaderPayloadLength(),motemsg->getRFIDReaderPayload());
			}
			// fixme -- extend for other message types as needed
			// if we have some leftover data, use that to start the next moteMsg
			CHAR *buf = NULL;
			int buflength = motemsg->extraDataLength();
			if ( buflength <= 0 ) {
				// no left over data
				delete motemsg;
				motemsg = NULL;
				return;
			}
			// we've got left over data
			buf = new CHAR[buflength];
			// fixme -- check for failed mallocs throughout
			MEMCPY(buf,motemsg->getExtraData(),buflength);
			delete motemsg;
			motemsg = new MoteMsg(buflength,buf);
			return;
		}
		if ( beenThroughLoop == true ) {
			return;
		}
		beenThroughLoop = true;
		// got data, but it's incomplete 
		motemsg->addData(length,tmpbuf);
	}
	return;
}

/***
 *
 * These are the UNIX specific methods
 *
 ***/
#if !defined(_MSC_VER)

/***
 * UNIX specific initialization method
 **/
void HandheldRFIDReader::_ctor() {
	fd = -1;
	tid = 0;
	shutdownEvent = false;
}
/***
 * UNIX specific connection to the serial port.
 * device - the devicename to connect to e.g. "/ttyusb0"
 * returns 0 for OK, -1 for not OK
 ***/
int HandheldRFIDReader::_connect(char *device) { 

	errno = 0;
	if ( fd > 0 ) {
		fprintf(stderr,"Already connected?");
		return -1;
	}

	fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd < 0) {
		printf("open error %d %s\n", errno, strerror(errno));
		return -1;
	}
	else {
		struct termios my_termios;
		//("fd is %d\n", fd);
		tcgetattr(fd, &my_termios);
		tcflush(fd, TCIFLUSH);
		cfmakeraw(&my_termios);
		my_termios.c_cflag &= ~(CSTOPB);
		// no flow control
		my_termios.c_cflag &= ~(CRTSCTS);
        	my_termios.c_iflag &= ~(IXON | IXOFF);
		if ( BaudRate == 19200 ) {
			cfsetospeed(&my_termios, B19200);
		}
		else if ( BaudRate == 57600 ) {
			cfsetospeed(&my_termios, B57600);
		}
		else {
			fprintf(stderr,"Can't handle this baudrate %d. Defaulting to 19200\n",BaudRate);
			cfsetospeed(&my_termios, B19200);
		}
		tcsetattr(fd, TCSANOW, &my_termios);
		tcflush(fd, TCIOFLUSH);
	}
	return 0;
}
/***
 * UNIX specific disconnect from serial port
 * returns 0
 ***/
int HandheldRFIDReader::_disconnect() {
	if ( fd == -1 ) return 0;
	close(fd);
	fd = -1;
	return 0;
}

/***
 * UNIX specific method to start processing incoming messages via a separate thread
 * returns 0 if OK -1 if not
 ***/
int HandheldRFIDReader::_startProcessingIncomingMessages() {
	// if thread already started just return
	if ( tid != 0 ) return 0;
	// create a thread to process the messages
	int ret = pthread_create(&tid,NULL,_processIncomingMessages,(void *)this);
	if ( ret != 0 ) {
		fprintf(stderr,"Could not create incoming messages thread. ret = %d\n",ret);
		return -1;
	}
	return 0;
}
/***
 * UNIX specific method to stop processing incoming messages
 * returns 0
 ***/
int HandheldRFIDReader::_stopProcessingIncomingMessages() {
	// if already shutdown just return
	if ( tid == 0 ) return 0;
	// tell the thread to shutdown
	shutdownEvent = true;
	// wait until the thread really does shutdown
	pthread_join(tid,NULL);
	shutdownEvent = false;
	tid = 0;
	return 0;
}
/***
 * UNIX specific method to look for incoming messages
 * param is the creating thread's this. use it for access to this object.
 * never returns but will thread exit if shutdownEvent is set to true
 ***/
void *HandheldRFIDReader::_processIncomingMessages(void *param) {

	// get my this
	HandheldRFIDReader *pThis = (HandheldRFIDReader *)param;

	// set up polling for incoming events
	struct pollfd *fds;
	fds = (struct pollfd *)calloc(sizeof(struct pollfd),1);
	fds[0].fd = pThis->fd;
	fds[0].events |= POLLIN;

	//loop forever. wake up every 1000 milliseconds to check for shutdownEvent
	for ( ; ; ) {
		int rv = poll(fds,1,10000); // fixme in millisec
		if ( rv == -1 ) {
			fprintf(stderr,"couldnt poll errno = %d\n",errno);
		}
		// got some data ... process it
		if ( fds[0].revents & POLLIN ) {
			pThis->_getData();
		}
		// main thread wants me to shutdown
		if ( pThis->shutdownEvent == true ) {
			pthread_exit(0);
		}

	}
}

/**
 * UNIX specific method to get incoming data
 ***/
void HandheldRFIDReader::_getData() {

	CHAR tmpbuf[INCOMING_MOTEMSG_LEN];
	unsigned long bytesReadThisTime = 0;
	bool ret;
	bytesReadThisTime = read(fd,tmpbuf,INCOMING_MOTEMSG_LEN);
#ifdef DEBUG
	printf("read %d bytes!\n",bytesReadThisTime);
	for ( int i = 0 ; i < bytesReadThisTime ; i++ ) printf(" %x (%c) ",tmpbuf[i],tmpbuf[i]); printf("\n");
#endif
	if ( bytesReadThisTime <= 0 ) {
		fprintf(stderr,"Could not read!\n");
		return;
	}
	// got some data. use cross platform method processIncomingData to interpret it
	processIncomingData(bytesReadThisTime, tmpbuf);
	return;
}
#else
/***
 *
 * These are the MSVC-specific methods
 *
 ***/

/***
 * Windows specific initialization
 **/
void HandheldRFIDReader::_ctor() { ;
	hPort = 0;
	ByteSize = BYTESIZE;
	Parity = NOPARITY;
	hShutdownIncomingMessageProcessingEvent = 0;
}

/***
 * Windows specific connection method.
 * device is the name of the COM port e.g. "COM4"
 * returns 0 if OK -1 if not OK
 ***/
int HandheldRFIDReader::_connect(char *device) {

	int ret = 0;
	SECURITY_ATTRIBUTES sa;
	DCB      dcb;

	if (hPort != 0) {
		fprintf(stderr,"already connected?");
		return -1;
	}

	memset(&dcb,0,sizeof(DCB));

	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.lpSecurityDescriptor = NULL;
	sa.bInheritHandle = TRUE;

	// open the device
	hPort = CreateFile (device, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL );
	if( hPort == INVALID_HANDLE_VALUE) {
		DWORD err = GetLastError();
		char errbuf[128];
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM,NULL,err,MAKELANGID(LANG_NEUTRAL,SUBLANG_DEFAULT),errbuf,strlen(errbuf),NULL);
		fprintf(stderr,"cannot open %s! err = %d msg = %s\n",device,err,errbuf);
		return -1;
	}

	// set up the connection parameters
	SetupComm(hPort, OUTGOING_MOTEMSG_LEN, OUTGOING_MOTEMSG_LEN); // set buffer sizes
	GetCommState(hPort, &dcb);
	dcb.DCBlength		= OUTGOING_MOTEMSG_LEN;
	dcb.BaudRate        = BaudRate;
	dcb.ByteSize        = (BYTE)ByteSize;
	dcb.Parity			= Parity;
	dcb.fParity			= Parity==NOPARITY?0:1;
	dcb.StopBits		= ONESTOPBIT;
	dcb.fOutxCtsFlow    = 0;
	dcb.fOutxDsrFlow    = 0;
	dcb.fDtrControl     = DTR_CONTROL_DISABLE;
	dcb.fDsrSensitivity = 0;
	dcb.fRtsControl     = RTS_CONTROL_DISABLE;
	dcb.fOutX           = 0;
	dcb.fInX            = 0;
	dcb.fErrorChar      = 0;
	dcb.fBinary         = 1;
	dcb.fNull           = 0;
	dcb.fAbortOnError   = 0;
	dcb.wReserved       = 0;
	dcb.XonLim          = 2;
	dcb.XoffLim         = 4;
	dcb.XonChar         = 0x13;
	dcb.XoffChar        = 0x19;
	dcb.EvtChar         = 0;
	SetCommState(hPort, &dcb);

	if ( SetCommMask (hPort, EV_RXCHAR | EV_RXFLAG) == false ) {
		fprintf(stderr,"could not set comm mask!");
		return -1;
	}

	COMMTIMEOUTS timeouts;
	timeouts.ReadIntervalTimeout = 20;
	timeouts.ReadTotalTimeoutConstant = 100;
	timeouts.ReadTotalTimeoutMultiplier = 100;
	timeouts.WriteTotalTimeoutConstant = 100;
	timeouts.WriteTotalTimeoutMultiplier = 100;

	if (SetCommTimeouts(hPort, &timeouts) == false) {
		fprintf(stderr,"could not set timeouts!\n");
		return -1;
	}
	return 0;
}

/***
 * Windows specific disconnect method
 * returns 0
 ***/
int HandheldRFIDReader::_disconnect() {
	// fxime purge comm
	if (hPort == 0) return 0;
	CloseHandle(hPort);
	hPort = 0;
	return 0;
}

/***
 * Windows specific method to start processing incoming messages. Creates a separate thread to handle this work.
 * returns 0
 ***/
int HandheldRFIDReader::_startProcessingIncomingMessages() {

	// fixme better to look at the handle instead
	if ( hShutdownIncomingMessageProcessingEvent != 0 ) {
		fprintf(stderr,"already processing incoming messages");
		return 0;
	}
	// start a thread
	DWORD tid;
	HANDLE incomingMessagesHandle = CreateThread(NULL,0,(unsigned long (__stdcall *)(void *))HandheldRFIDReader::_processIncomingMessages,(void *)this,NULL,&tid);
	return 0;

}

/***
 * Windows specific method to stop processing incoming messages
 * returns 0
 **/
int HandheldRFIDReader::_stopProcessingIncomingMessages() {
#ifdef DEBUG
	fprintf(stderr,"_stopProcessingIncomingMessages\n");
#endif
	// stop a thread
	if ( hShutdownIncomingMessageProcessingEvent != 0 ) {
		SetEvent(hShutdownIncomingMessageProcessingEvent);
	}
	return 0;
}

/***
 * Windows specific method to process incoming messages
 * param is a pointer to the main thread's this. Allows object access.
 ***/
void *HandheldRFIDReader::_processIncomingMessages(void *param) {

	// get "this"
	HandheldRFIDReader *pThis = (HandheldRFIDReader *)param;

	DWORD dwError = 0;
	DWORD dwEvtMask = 0;
	COMSTAT comState;
	OVERLAPPED overlapped;

	// initialize the shutdown event
	pThis->hShutdownIncomingMessageProcessingEvent = CreateEvent(NULL,TRUE,FALSE,NULL);

	// create an overlapped event
	memset(&overlapped,0,sizeof(overlapped));
	overlapped.hEvent = CreateEvent(NULL,TRUE,FALSE,NULL);

	// loop forever, waiting for data events or shutdown events
	HANDLE hArray[2];
	hArray[0] = overlapped.hEvent;
	hArray[1] = pThis->hShutdownIncomingMessageProcessingEvent;
	ClearCommError(pThis->hPort,&dwError,&comState);
	for ( ; ; ) {

		if ( SetCommMask (pThis->hPort, EV_RXCHAR | EV_RXFLAG) == false ) {
			fprintf(stderr,"could not set comm mask!");
		}

		if ( !WaitCommEvent(pThis->hPort, &dwEvtMask, &overlapped) ) {
		
			if ( GetLastError() != ERROR_IO_PENDING ) {
				fprintf(stderr,"got some error = %d\n",GetLastError());
				ClearCommError(pThis->hPort,&dwError,&comState);
				SetLastError(0);
				continue;
			}
			// else: no data to process. fall through to the wait
	
		}
		else {
			// data to process. make sure this is really true, and fall through
			ClearCommError(pThis->hPort,&dwError,&comState);
			if (comState.cbInQue == 0) continue;
		}
		switch (WaitForMultipleObjects(2,hArray,FALSE,INFINITE)) {
			case WAIT_OBJECT_0:
				// got some data from the handheld reader
				if ( dwEvtMask & EV_RXCHAR ) pThis->_getData(overlapped);
				ResetEvent(hArray[0]);
				break;
			case WAIT_OBJECT_0+1:
				// shut down incoming messages thread
				ResetEvent(hArray[1]);
				PurgeComm(pThis->hPort,PURGE_RXABORT|PURGE_RXCLEAR);
				//pThis->hShutdownIncomingMessageProcessingEvent = 0;
				ExitThread(0);
		}
	}
}

/**
 * Windows specific method to read incoming data
 * overlapped is an OVERLAPPED structure
 **/
void HandheldRFIDReader::_getData(OVERLAPPED overlapped) {

	CHAR tmpbuf[INCOMING_MOTEMSG_LEN];
	unsigned long bytesReadThisTime = 0;
	DWORD dwError;
	COMSTAT comState;
	BOOL ret;

	memset(tmpbuf,0,INCOMING_MOTEMSG_LEN);
	int index = 0;

	for (;;) {

		ClearCommError(hPort,&dwError,&comState);
		if (comState.cbInQue == 0) break;

		ret = ReadFile(hPort,&tmpbuf[index],INCOMING_MOTEMSG_LEN-index,&bytesReadThisTime,&overlapped);
		if ( ret == false || GetLastError() == ERROR_IO_PENDING ) {
			if ( !GetOverlappedResult(hPort,&overlapped,&bytesReadThisTime,true)) {
				fprintf(stderr,"bad getoverlappedresult! %d\n",GetLastError());
				return;
			}
			continue;
		}
		else if ( ret == false ) {
			fprintf(stderr,"bad Readfile! %d\n",GetLastError());
			return;
		}
	
#ifdef DEBUG
		printf("read %d bytes!\n",bytesReadThisTime);
		for ( int i = 0 ; i < bytesReadThisTime ; i++ ) { printf(" %c ",tmpbuf[i]); } printf("\n");	
#endif
		index = index + bytesReadThisTime;
		if (index == INCOMING_MOTEMSG_LEN ) break;
	}
	processIncomingData(INCOMING_MOTEMSG_LEN, tmpbuf);
	return;


}
#endif
