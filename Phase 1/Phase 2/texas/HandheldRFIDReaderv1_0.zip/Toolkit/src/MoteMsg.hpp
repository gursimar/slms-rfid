/* $Header: /home/cvs/handheldreader/src/MoteMsg.hpp,v 1.1 2003/11/26 19:57:07 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/


#ifndef MOTEMSG_H
#define MOTEMSG_H

#include "RFIDMsg.hpp"
#include "chars.h"

enum {
	INCOMING_ADDR0_INDEX = 0,
	INCOMING_ADDR1_INDEX,
	INCOMING_MESSAGETYPE_INDEX,
	INCOMING_GROUP_INDEX,
	INCOMING_LEN_INDEX
};

enum {
	OUTGOING_SYNC_INDEX = 0,
	OUTGOING_ADDR0_INDEX,
	OUTGOING_ADDR1_INDEX,
	OUTGOING_MESSAGETYPE_INDEX,
	OUTGOING_GROUP_INDEX,
	OUTGOING_LEN_INDEX
};

const int INCOMING_MOTEMSG_HEADER_LEN = 5;
const int OUTGOING_MOTEMSG_HEADER_LEN = 6;
const int CRC_LEN = 2;
const int INCOMING_MOTEMSG_LEN = INCOMING_MOTEMSG_HEADER_LEN + RFIDMSG_LEN + CRC_LEN;
const int OUTGOING_MOTEMSG_LEN = OUTGOING_MOTEMSG_HEADER_LEN + RFIDMSG_LEN + CRC_LEN;

enum {
	UNKNOWN_MESSAGE_TYPE = -1,
	// types of messages we can send
	ADVERTISEMENT_MESSAGE_TYPE,
	// types of messages we can receive
	ID_MESSAGE_TYPE,
	READ_MESSAGE_TYPE,
	WRITE_MESSAGE_TYPE,
	ERROR_MESSAGE_TYPE,
};


class MoteMsg {
	public:
		MoteMsg();
		MoteMsg( int len, CHAR *buf);
		MoteMsg( int outgoingMessageType );
		MoteMsg( const MoteMsg& moteMsg);
		~MoteMsg();
		MoteMsg& operator=(const MoteMsg& moteMsg);
		void ctor_guts();
		CHAR *getMessageData() const;
		int getMessageDataLength() const;
		bool isCompleteMessage() const;
		int getMessageType() const;
		int getRFIDReaderPayloadLength() const;
		CHAR *getRFIDReaderPayload() const;
		int addData( int len, CHAR *buf);
		int extraDataLength();
		CHAR *getExtraData();
		bool isBadMessage();
	private:
		void parseMessage();
		CHAR *data;
		int datalen;
		int messageType;
		int messageLength;
		RFIDMsg *rfidMsg;
		CHAR *extradata;
		int extradatalen;	
		bool badMessage;
};

#endif

