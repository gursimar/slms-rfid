/* $Header: /home/cvs/handheldreader/src/Main.cpp,v 1.4 2003/12/03 23:48:12 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/

/***
 * Absurdly simple c++ console driver, demonstrating the use of the 
 * HandheldRFIDReader classes. In the real world, you'd want to subclass
 * the HandheldRFIDReader class and override processReadTagHeaderReplyMessage
 * to do whatever it is you'd like to do when you see a RFID tag.
 ***/

#if !defined(_MSC_VER)
#include <unistd.h>
#define SLEEP(x)	sleep(x)			// seconds
#else
#define SLEEP(x)	Sleep(x*1000)			// milliseconds
#endif
#include <stdio.h>
#include "HandheldRFIDReader.hpp"

int main(int argc, char **argv) {

	if ( argc == 1 ) {
		fprintf(stderr, "usage: %s devicename",argv[0]);
		return 0;
	}

	HandheldRFIDReader *conn = new HandheldRFIDReader();
	printf("about to connect ...\n");
	if ( conn->connect(argv[1]) < 0 ) {
		exit(-1);
	}
	printf("start processing incoming ..\n");
	conn->startProcessingIncomingMessages();
	SLEEP(60);
	printf("stop processing incoming ..\n");
	conn->stopProcessingIncomingMessages();
	SLEEP(30);
	printf("re-start processing incoming ..\n");
	conn->startProcessingIncomingMessages();
	SLEEP(60);
	printf("stop processing incoming ..\n");
	conn->stopProcessingIncomingMessages();
	printf("disconnect\n");
	conn->disconnect();
	exit(0);
}

