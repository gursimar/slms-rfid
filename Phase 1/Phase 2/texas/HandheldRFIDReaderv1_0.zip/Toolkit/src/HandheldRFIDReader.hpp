/* $Header: /home/cvs/handheldreader/src/HandheldRFIDReader.hpp,v 1.1 2003/11/26 19:55:27 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/

#ifndef HANDHELD_H
#define HANDHELD_H

#if defined(_MSC_VER)
#include <windows.h>
#else
#include <pthread.h>
#endif
#include <stdio.h>
#include "chars.h"

const int BAUDRATE = 19200;
#if defined(_MSC_VER)
const int BYTESIZE = 8;
#endif

class HandheldRFIDReader;

class HandheldRFIDReader {
public:
	HandheldRFIDReader();
	HandheldRFIDReader(int baudrate);
	// default bitwise copy constructor is fine
	~HandheldRFIDReader();
	// default bitwise assignment operator is fine
	int connect(char *device);
	int disconnect();
	int startProcessingIncomingMessages();	// starts thread
	int stopProcessingIncomingMessages();	// stops thread
	int processReadTagHeaderReplyMessage(int length, CHAR *payload);	// user overrides
	//int sendReadTagContentsMessage();
private:
	static void *_processIncomingMessages(void *);
	void processIncomingData(int length, CHAR *tmpbuf);
	void _ctor();
	int _connect(char *device);
	int _disconnect();
	int _startProcessingIncomingMessages();
	int _stopProcessingIncomingMessages();
#if defined(_MSC_VER)
	void _getData(OVERLAPPED overlapped);
#else
	void _getData();
#endif
	//int processOutgoingMessage();	
	int BaudRate;

#if defined(_MSC_VER)
	int ByteSize;
	int Parity;
	HANDLE hPort;
	HANDLE hShutdownIncomingMessageProcessingEvent;
#else
	int fd;
	bool shutdownEvent;
	pthread_t tid;
#endif
};

/**
 * 	conn = new HandheldRFIDReader();
 * 	conn.connect();
 * 	conn.startProcessingIncomingMessages();	// sep thread
 * 	...
 * 	conn.sendReadTagContentsMessage(...);
 * 	conn.stopProcessingIncomingMessages();	// kills thread
 * 	conn.disconnect();
 ***/

#endif
