/* $Header: /home/cvs/handheldreader/src/MoteMsg.cpp,v 1.2 2003/12/04 01:15:19 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/

#if defined(_MSC_VER)
#include <windows.h>
#else
#include <string.h>
#endif
#include <stdio.h>
#include "MoteMsg.hpp"
#include "RFIDMsg.hpp"

/***
 * This class encapsulates all the information about a Mote messages,
 * both incoming and outgoing.
 ***/

/***
 * Constructor
 * ***/
MoteMsg::MoteMsg() {
	data = NULL;
	datalen = 0;
	ctor_guts();
/***
 * Constructor
 * len - length of buffer being passed to init MoteMsg
 * buf - buffer being passed to init MoteMsg
 * ***/
}
MoteMsg::MoteMsg( int len, CHAR *buf) {
	data = new CHAR[len];
	MEMCPY(data,buf,len);
	datalen = len;
	ctor_guts();
};
/***
 * Constructor
 * msgType - message type to construct. used for outgoing messages only
 * FIXME - expand to other outgoing message types
 * ***/
MoteMsg::MoteMsg( int msgType ) {
	extradata = NULL;
	extradatalen = -1;
	// fixme - not tested yet
	if ( msgType == ADVERTISEMENT_MESSAGE_TYPE ) {
		data = new CHAR[OUTGOING_MOTEMSG_HEADER_LEN];
		datalen = OUTGOING_MOTEMSG_HEADER_LEN;
		data[OUTGOING_SYNC_INDEX] = (CHAR)0xab;
		data[OUTGOING_ADDR0_INDEX] = (CHAR)0xff;
		data[OUTGOING_ADDR1_INDEX] = (CHAR)0xff;
		data[OUTGOING_MESSAGETYPE_INDEX] = (CHAR)0x15;
		data[OUTGOING_GROUP_INDEX] = (CHAR)0x11;
		data[OUTGOING_LEN_INDEX] = (CHAR)0x1d;
		rfidMsg = new RFIDMsg();
		messageType = ADVERTISEMENT_MESSAGE_TYPE;
		messageLength = rfidMsg->getDataLength() + OUTGOING_MOTEMSG_HEADER_LEN;
	}
}
/***
 * Copy Constructor. Default won't work.
 * moteMsg - moteMsg to copy
 * ***/
MoteMsg::MoteMsg(const MoteMsg &moteMsg) {
	if ( this == &moteMsg  ) return;
	int len = moteMsg.getMessageDataLength();
	data = new CHAR[moteMsg.getMessageDataLength()];
	MEMCPY(data,moteMsg.getMessageData(),moteMsg.getMessageDataLength());
	datalen = moteMsg.getMessageDataLength();
	ctor_guts();
}
/***
 * Assignment operator. Default won't work
 * moteMsg - moteMsg to assign
 * ***/
MoteMsg& MoteMsg::operator=(const MoteMsg& moteMsg) {
	if ( this == &moteMsg ) return *this;
	data = new CHAR[moteMsg.getMessageDataLength()];
	MEMCPY(data,moteMsg.getMessageData(),moteMsg.getMessageDataLength());
	datalen = moteMsg.getMessageDataLength();
	ctor_guts();
	return *this;
}
/***
 * Factored out constructor code
 * ***/
void MoteMsg::ctor_guts() {
	messageType = UNKNOWN_MESSAGE_TYPE;
	messageLength = -1;
	rfidMsg = NULL;
	extradata = NULL;
	extradatalen = -1;
	badMessage = false;
	parseMessage();
}
/***
 * Destructor. Releases malloc'ed data, like the good citizen it is.
 * ***/
MoteMsg::~MoteMsg() {
	if ( data != NULL ) delete data;
	if ( rfidMsg != NULL ) delete rfidMsg;
	if ( extradata != NULL ) delete extradata;
};

/***
 * Returns MoteMsg payload. Only works on incoming messages.
 * Returns array of chars, not guaranteed to be null terminated.
 * ***/
CHAR *MoteMsg::getMessageData() const {
	if ( isCompleteMessage() == false || rfidMsg == NULL ) return NULL;
	return &data[INCOMING_MOTEMSG_HEADER_LEN];
}
/***
 * Returns MoteMsg payload length. Only works on incoming messages.
 * Returns an int.
 * ***/
int MoteMsg::getMessageDataLength() const {
	return messageLength;
}
/***
 * Tells me if this is a complete message. Only works on incoming messages.
 * Returns boolean true if true false if false
 * ***/
bool MoteMsg::isCompleteMessage() const {
	if ( datalen >= INCOMING_MOTEMSG_LEN ) return true;
	return false;
}
/***
 * Returns message type
 * Returns int. See header for possible values.
 * ***/
int MoteMsg::getMessageType() const {
	return messageType;
}
/***
 * Returns the length of the RFIDMsg payload
 * Returns -1 if no RFIDMsg or length.
 ***/
int MoteMsg::getRFIDReaderPayloadLength() const {
	if ( rfidMsg == NULL ) return -1;
	return rfidMsg->getDataLength();
}
/***
 * Returns the RFIDMsg payload, e.g. the actual tag.
 * Returns NULL if no RFIDMsg or an array of chars. Chars
 * are NOT guaranteed to be null terminated.
 ***/
CHAR *MoteMsg::getRFIDReaderPayload() const {
	if ( rfidMsg == NULL ) return NULL;
	return rfidMsg->getData();
}
/***
 * Add some data to the MoteMsg. 
 * len - number of chars being added
 * buf - array of chars being added
 * Returns 0 no matter what.
 ***/
int MoteMsg::addData( int len, CHAR *buf) {
	if ( isCompleteMessage() == true ) return -1;
	CHAR *newdata = new CHAR[len+datalen];
	MEMCPY(newdata,data,datalen);
	MEMCPY(&newdata[datalen],buf,len);
	delete data;
	data = newdata;
	datalen += len;
	parseMessage();
	return 0;
}

/***
 * Returns the length of any "extra" data we might have.
 * Returns the length
 ***/
int MoteMsg::extraDataLength() {
	return extradatalen;
}
/***
 * Returns any "extra" data we might have.
 * Returns an array of chars. Not guaranteed to be null-terminated.
 ***/
CHAR *MoteMsg::getExtraData() {
	return extradata;
}
/**
 * Tell me if this message was parseable.
 * Returns a boolean true if true false if false.
 ***/
bool MoteMsg::isBadMessage() {
	return badMessage;
}

/**
 * Parse this message data.
 * Returns void.
 ***/
void MoteMsg::parseMessage() {
#ifdef DEBUG
	printf("motemsg: parseMessage. datalen = %d\n",datalen);
	for ( int i = 0 ; i < datalen ; i++ ) printf(" %x (%c)",data[i],data[i]); printf("\n");
#endif
	// not enough data yet to parse
	if ( datalen < INCOMING_MOTEMSG_HEADER_LEN ) {
		return;
	}
	// figure out what message type this is
	switch ( data[INCOMING_MESSAGETYPE_INDEX] ) {
		case 0x04:
			messageType = ID_MESSAGE_TYPE;
			break;
		case 0x0a:
			messageType = WRITE_MESSAGE_TYPE;
			break;
		case 0x0b:
			messageType = READ_MESSAGE_TYPE;
			break;
		case 0x14:
			messageType = ERROR_MESSAGE_TYPE;
			break;
		case 0x15:
			messageType = ADVERTISEMENT_MESSAGE_TYPE;
			break;
		default:
			fprintf(stderr,"dont understand this message type %x\n",data[INCOMING_MESSAGETYPE_INDEX]);
			badMessage = true;
			break;
	}
	// if there's enough data for a full message, build a RFIDMsg. If there's extra data, save a pointer to it
	// for subsequent retrieval.
	if ( datalen >= INCOMING_MOTEMSG_LEN ) {
		messageLength = INCOMING_MOTEMSG_LEN;
		rfidMsg = new RFIDMsg(INCOMING_MOTEMSG_LEN-INCOMING_MOTEMSG_HEADER_LEN,&data[INCOMING_MOTEMSG_HEADER_LEN]);
		if ( datalen > INCOMING_MOTEMSG_LEN ) {
			extradatalen = datalen - INCOMING_MOTEMSG_LEN;
			extradata = new CHAR[extradatalen];
			MEMCPY(extradata,&data[INCOMING_MOTEMSG_LEN],extradatalen);
		}
	}
	return;
}
	
