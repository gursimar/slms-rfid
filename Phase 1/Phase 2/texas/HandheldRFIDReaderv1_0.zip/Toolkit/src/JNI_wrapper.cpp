/* $Header: /home/cvs/handheldreader/src/JNI_wrapper.cpp,v 1.3 2003/12/03 23:41:23 powledge Exp $ */
/*

Copyright (c) 2003 Intel Corporation
All rights reserved.
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
Neither the name of the Intel Corporation nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE INTEL OR CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

EXPORT LAWS: THIS LICENSE ADDS NO RESTRICTIONS TO THE EXPORT LAWS OF YOUR
JURISDICTION. It is licensee's responsibility to comply with any export
regulations applicable in licensee's jurisdiction. Under CURRENT (May 2000)
U.S. export regulations this software is eligible for export from the U.S.
and can be downloaded by or otherwise exported or reexported worldwide EXCEPT
to U.S. embargoed destinations which include Cuba, Iraq, Libya, North Korea,
Iran, Syria, Sudan, Afghanistan and any other country to which the U.S. has
embargoed goods and services.

*/

#include <jni.h>
#include <string.h>
#include "HandheldRFIDReader.hpp"
#include "HandheldRFIDReader.h"
#include "vector"
using namespace std;

// need to cache these for use in later callbacks, which are done outside of a
// JNI thread context
static JavaVM *cached_jvm;
static jclass cached_mid;

// one of these structs is allocated for each instantiation of a handheldrfidreader
// it holds a pointer to the handheldrfidreader plus some info needed for callbacks
// outside of a JNI thread context
struct ReaderHandle {
	HandheldRFIDReader *reader;
	jobject java_peer;
	jmethodID mid;
};
typedef struct ReaderHandle *ReaderHandlePointer;

// list of active connections
vector<ReaderHandlePointer> handlelist;

// initialize a JNI HandheldRFIDReader instantiation
// env - Java thread context
// obj - calling Java object
// returns the address of the created Readerhandle object, to be used for subsequent calls 
JNIEXPORT jlong JNICALL Java_HandheldRFIDReader_HandheldRFIDReader_1init(JNIEnv *env, jobject obj) {
	// need to collect information like jvm for a callback from an arbitrary thread context
	env->GetJavaVM(&cached_jvm);
	ReaderHandle *handle = new ReaderHandle();
	// create the actual reader object
	handle->reader = new HandheldRFIDReader();
	// needed for callback
	handle->java_peer = env->NewGlobalRef(obj);
	jclass cls = env->GetObjectClass(obj);
	// needed for callback
	handle->mid = env->GetMethodID(cls,"processReadTagHeaderReplyMessage","(Ljava/lang/String;)I");
	// save this handle on my list
	handlelist.push_back(handle);
	// return the handle to Java
	return reinterpret_cast<jlong>(handle);	
}

// release all the resources associated with a handle
// env - Java thread context
// obj - calling Java object
// handle - reference to previously created HandheldRFIDReader and associated objects
// returns - 0 no matter what
JNIEXPORT jint JNICALL Java_HandheldRFIDReader_HandheldRFIDReader_1cleanup(JNIEnv *env, jobject obj, jlong handle) {
	ReaderHandle *readerHandle;
	for ( int i = 0 ; i < handlelist.size() ; i++ ) {
		jobject peertmp = (handlelist[i])->java_peer;
		readerHandle = reinterpret_cast<ReaderHandle *>(handle);
		if ( peertmp != readerHandle->java_peer ) {
			continue;
		}
		handlelist.erase(handlelist.begin()+i);
		break;
	}
	env->DeleteGlobalRef(readerHandle->java_peer);
	delete readerHandle;
	return 0;
}

// make a connection to a handheld rfid reader
// env - Java thread context
// obj - calling Java object
// device - name of device to connect to
// handle - reference to previously created HandheldRFIDReader and associated objects
// returns - 0 if OK 1 if not
JNIEXPORT jint JNICALL Java_HandheldRFIDReader_HandheldRFIDReader_1connect(JNIEnv *env, jobject obj, jstring device_jstring, jlong handle) {
	ReaderHandle *readerHandle = reinterpret_cast<ReaderHandle *>(handle);
	const char *device = env->GetStringUTFChars(device_jstring,NULL);
	int ret = (readerHandle->reader)->connect((char *)device);
	env->ReleaseStringUTFChars(device_jstring,device);
	return (jint)ret;
}

// start processing incoming messages
// env - Java thread context
// obj - calling Java object
// handle - reference to previously created HandheldRFIDReader and associated objects
// returns - 0 if OK 1 if not
JNIEXPORT jint JNICALL Java_HandheldRFIDReader_HandheldRFIDReader_1startProcessingIncomingMessages(JNIEnv *env, jobject obj, jlong handle) {
	ReaderHandle *readerHandle = reinterpret_cast<ReaderHandle *>(handle);
	return (readerHandle->reader)->startProcessingIncomingMessages();
}

// stop processing incoming messages
// env - Java thread context
// obj - calling Java object
// handle - reference to previously created HandheldRFIDReader and associated objects
// returns - 0 if OK 1 if not
JNIEXPORT jint JNICALL Java_HandheldRFIDReader_HandheldRFIDReader_1stopProcessingIncomingMessages(JNIEnv *env, jobject obj, jlong handle) {
	ReaderHandle *readerHandle = reinterpret_cast<ReaderHandle *>(handle);
	return (readerHandle->reader)->stopProcessingIncomingMessages();
}

// disconnect from a handheld rfid reader
// env - Java thread context
// obj - calling Java object
// handle - reference to previously created HandheldRFIDReader and associated objects
// returns - 0 if OK 1 if not
JNIEXPORT jint JNICALL Java_HandheldRFIDReader_HandheldRFIDReader_1disconnect(JNIEnv *env, jobject obj, jlong handle) {
	ReaderHandle *readerHandle = reinterpret_cast<ReaderHandle *>(handle);
	int ret = (readerHandle->reader)->disconnect();
	return ret;
}

// Normally the HandheldRFIDReader supplies a processReadTagHeaderReplyMessage method, which
// is typically overridden to give whatever functionality the developer desires. But since
// I want to do a callback into Java when a tag seen message is encountered, for the JNI lib
// I don't compile the method in HandheldRFIDReader (via a ifdef preprocessor command) and
// use this one instead. 
//
// It will do a callback to the calling java object, and use its processReadTagHeaderReplyMessage
// method. The one complication here is that since this is a callback, this is not being
// invoked in any particular Java thread context. So I first figure out what HandheldRFIDReader
// object I'm part of, and then use that information to find the right ReaderHandle object
// for me. Once I have that I can find the jmethodID for the Java callback and invoke that. 
//
// length - length of tag
// payload - the tag that was seen
// returns 0 if OK 1 if not
int HandheldRFIDReader::processReadTagHeaderReplyMessage(int length, CHAR *payload) {
	// first attach to some JNI thread so I can get a context to work with
	JNIEnv *env;
	cached_jvm->AttachCurrentThread((void **)&env,NULL);
	// now, use my handheldrfidreader instance to find out what readerhandle I belong to
	// fixme: can be done tons more efficiently
	for ( int i = 0 ; i < handlelist.size() ; i++ ) {
		ReaderHandle *handle = handlelist[i];
		HandheldRFIDReader *reader = handle->reader;
		// is this my readerhandle instance?
		if ( reader != this ) {
			// no, keep looking
			continue;
		}
		// yes. find out the java object and processReadTagHeaderReplyMessage
		// jmethodID to use for the callback
		jmethodID mid = (jmethodID)handle->mid;
		jobject obj = (jobject)handle->java_peer;
		// turn the char[] into a jstring for the callback
		char *payloadasstring = new char[length+1];
		memcpy(payloadasstring,payload,length);
		payloadasstring[length] = '\0';
		jstring payload_jstring = env->NewStringUTF((const char *)payloadasstring);
		// now do the callback
		env->CallVoidMethod(obj,mid,payload_jstring);
		// clean up alloc'ed mem
		delete payloadasstring;
		return 0;
	}
	fprintf(stderr,"ERROR: wasn't able to match handles!\n");
	return 1;
}

